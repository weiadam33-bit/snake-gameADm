# Friendly Snake – Café Edition ☕
A cozy, PWA-ready snake game themed around coffeehouse vibes.

## How to use
1. Unzip and open folder.
2. Run a local web server (e.g. `npx serve .`).
3. Open in browser and install as PWA.

## Assets
All assets are placeholders:
- assets/images/background.png
- assets/images/coffee_cup.png
- assets/images/croissant.png
- assets/images/mug.png
- assets/sounds/background.mp3
- assets/sounds/eat.mp3
- assets/sounds/powerup.mp3
- assets/sounds/crash.mp3
Replace them with your own artwork and audio!