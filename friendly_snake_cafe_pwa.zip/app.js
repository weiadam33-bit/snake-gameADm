const canvas=document.getElementById('game');
const ctx=canvas.getContext('2d');
let snake=[{x:10,y:10}],dir={x:1,y:0},food={x:5,y:5},running=false,score=0;
const tile=30,grid=20;
const eatSound=new Audio('assets/sounds/eat.mp3');
const crashSound=new Audio('assets/sounds/crash.mp3');
const bgMusic=new Audio('assets/sounds/background.mp3');
bgMusic.loop=true;
document.getElementById('startBtn').onclick=()=>{if(!running){running=true;bgMusic.play();loop();}};
document.getElementById('pauseBtn').onclick=()=>running=false;
document.getElementById('muteBtn').onclick=()=>{bgMusic.muted=!bgMusic.muted;};
window.addEventListener('keydown',e=>{if(e.key==='ArrowUp'&&dir.y===0)dir={x:0,y:-1};if(e.key==='ArrowDown'&&dir.y===0)dir={x:0,y:1};if(e.key==='ArrowLeft'&&dir.x===0)dir={x:-1,y:0};if(e.key==='ArrowRight'&&dir.x===0)dir={x:1,y:0};});
function loop(){if(!running)return;update();draw();setTimeout(loop,150);}
function update(){const head={x:(snake[0].x+dir.x+grid)%grid,y:(snake[0].y+dir.y+grid)%grid};
if(snake.some(s=>s.x===head.x&&s.y===head.y)){crashSound.play();running=false;return;}
snake.unshift(head);
if(head.x===food.x&&head.y===food.y){score++;eatSound.play();food={x:Math.floor(Math.random()*grid),y:Math.floor(Math.random()*grid)};}
else snake.pop();}
function draw(){ctx.fillStyle='#3b2f2f';ctx.fillRect(0,0,canvas.width,canvas.height);
ctx.fillStyle='#fff';snake.forEach(s=>ctx.fillRect(s.x*tile,s.y*tile,tile-2,tile-2));
ctx.fillStyle='#c77';ctx.fillRect(food.x*tile,food.y*tile,tile-2,tile-2);}